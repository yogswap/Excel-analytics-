// Main React App component
