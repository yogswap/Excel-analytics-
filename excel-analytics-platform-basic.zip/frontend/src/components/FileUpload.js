// Component for file upload
