// Component for chart
